<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('css/login.css')}}">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        html {
            background-color: #ed5656;
         }
    </style>
    <title>login</title>
</head>
<body>
    <div class="wrapper fadeInDown">
        <div id="formContent">
          <!-- Tabs Titles -->
          <h2 class="active"> Cpanel </h2>
          <!-- Login Form -->
         <h1>welcome in cpanel</h1>
      
          <!-- Remind Passowrd -->
          <div id="formFooter">
            {{-- <a class="underlineHover" href="#">Forgot Password?</a> --}}
          </div>
      
        </div>
      </div>
</body>
</html>