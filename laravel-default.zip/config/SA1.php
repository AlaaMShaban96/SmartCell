<?php
return [
    
    "type"=>env('type'),
    "project_id"=>env('project_id'),
    "private_key_id"=>env('private_key_id'),
    "private_key"=>env('private_key'),
    "client_email"=>env('client_email'),
    "client_id"=>env('client_id'),
    "auth_uri"=>env('auth_uri'),
    "token_uri"=>env('token_uri'),
    "auth_provider_x509_cert_url"=>env('auth_provider_x509_cert_url'),
    "client_x509_cert_url"=>env('client_x509_cert_url'),

];