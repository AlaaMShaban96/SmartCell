<?php
return[
    'delivered'=>'',
    'recovery'=>'',
    'wasCanceled'=>'',
    'connecting'=>'',
    'personalReceipt'=>''
];