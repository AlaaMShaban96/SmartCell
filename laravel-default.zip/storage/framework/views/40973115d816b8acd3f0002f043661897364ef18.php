<?php $__env->startSection('content'); ?>
    <div class="error__title">404</div>
    <div class="error__subtitle">هناك مشكلة في الخادم</div>
    <br>
    <br>
    <a href="<?php echo e(url('/')); ?>" class="error__button error__button--active">الصفحة الرئسية</a>

    
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alaa/Projects/LaravelGoogleSheets/resources/views/errors/404.blade.php ENDPATH**/ ?>