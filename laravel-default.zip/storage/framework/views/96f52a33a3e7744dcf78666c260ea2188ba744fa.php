<!doctype html>
<html class="no-js" lang="">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SmartCell</title>
    <meta name="description" content="SmartCell">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <?php echo $__env->make('Dashbord.layout.include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->yieldContent('style'); ?>
  

</head>

<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="<?php echo e(url('/')); ?>"><i class="menu-icon fa fa-laptop"></i>الرئيسية</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/order')); ?>"> <i class="menu-icon fa fa-book"></i>الطلبيات</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/item')); ?>"> <i class="menu-icon fa fa-qrcode"></i>المنتجات</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/location')); ?>"> <i class="menu-icon fa fa-map-marker"></i>الأماكن</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/team')); ?>"> <i class="menu-icon fa fa-users"></i>الموظفين</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/setting')); ?>"> <i class="menu-icon fa fa-cog"></i>الإعدادات</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/logout')); ?>"> <i class="menu-icon fa fa-sign-out"></i>تسجيل الخروج</a>
                    </li>
                 
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>
    <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        <header id="header" class="header">
            <div class="top-right">
                <div class="navbar-header">
                    <a class="navbar-brand" href="./"><img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo"></a>
                    
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            
        </header>
        <!-- /#header -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- Content -->
        <!-- /.content -->
        <div class="clearfix"></div>
        <!-- Footer -->
        <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                        Copyright &copy; SmarCell
                    </div>

                </div>
            </div>
        </footer>
        <!-- /.site-footer -->
            </div>
    <!-- /#right-panel -->
    <?php echo $__env->make('Dashbord.layout.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>

</body>
</html>
     <?php /**PATH /home/alaa/Projects/LaravelGoogleSheets/resources/views/Dashbord/layout/master.blade.php ENDPATH**/ ?>