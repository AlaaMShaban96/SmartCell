<?php
return[
  "type"=> "service_account",
  "project_id"=> "smartcell-acff1",
  "private_key_id"=> "2160a8bdd9c313ca8a122a1c0d3b762d0f9fb9ed",
  "private_key"=> "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC9qvlXnpVeWoI0\nw4MBo2z3mpdni7PWg5m2YbnYYiS1CvB/pGwyeMyMw26BW0lBFanErRtou948HPiG\nKd5OcqzydpC8/2OTQCBOR+QXea20589zpYK+9P5fB4qFpL5nxgJLor4GHkuV3S/+\ngVmYvZ6qMC3iItOnuLfAw/D139uKupCNMURWM9ki/ozeUHumkty38sikgXx7Rz9P\n8uOTGZKuvcivcKA4CTf1GYPX45VUfhGGJeOuEeXF6VTSWZFuXxoMeT7rEOSLVgcm\ntNzQd+ONnouOhfAC4PyHLsmWFsWDLgjdOBr9MIOUqXYuDV74aEx1riPrPrDVLbXE\ny6hjvKh3AgMBAAECggEAMBfsheU2Zuh4X7y7uWyhMt/GSIFKJrjT/0UkhNPODwIp\nHZSpwtqSs5bSrIZjOtetZqumaZZJseB+vDZdonK9m/WomeQAcdQu3Oqp0bIO8/Jb\nzi1Hy/f/kEUvQNgXV+UDq/4mRRLlg6jEhLpz56EdXHY/DDpchQj3vy9wKEiNOM3J\n5+FKxj2hZOlbx+2eZSjJR9xiupl7Iq0NTPXICOAdATaLhHlqdYcckDzt145adT9l\n+rM+piOAIEo47DvrvRC8HSWDbHD06KHFHs9oEMYgUUlAuAzgtSyPtCd9R5qdIE5S\nJ2nqA5zhk2hcc72+AV0rq0zih7swHZarZzZmUAiSwQKBgQDqTBpvNHQZEhRHxOOK\n/g516xst+4axeX7i1g9/XJvEhPZU4fnPWiikAiDj9uqPIrAuGCBaynYq3JPDV3Bj\nx2eJNKn1nmQQ5T/0cqNsN/fRZO24BmcATI7AvbImQShVeOhIaIfgOZeZQmyqY3Ve\nFAE2YVRlDs+Er/+SxvvYRtrDUQKBgQDPPJKOJyJwsPYXHGxhaSdZQ741KCjzTdGa\nxhCLJYNKlY8unldgFnNyl4j3zY84+bt5165SXW26DVCeuKv9eyXixL58cdtcHMlc\nLRzDr/l557gY7S8JzrQCxxC4LFs3ZbGz65U/s3Bpp4U7gbmm4RaAlRDp1Nv+35lm\n1jlYKbdtRwKBgHpTu6V+BHOmfdIu2QKTvKcSVkF+xodYwMfcLYE4r9c9+IK+7Te2\ngeuHdPawzyxmVwfp7tKYTHP6cGeX+oUN8l+vkGE+Dk7H8slFJU/2NLwt7vOa3CJK\n1mmJYT8Z294sX1KWyQJn71/ET4nyna+90Bg9XtvYjL5hSZWvsIPuEn/RAoGBALFe\nyqDYZeXF0BrfvPNyqLcCAB5HDSWRCUFLHIW7ya9ganggFfCrxovhnt1ZFqhRNmCG\ndTERvgRruQDgVnRRno+EjPS+Dl28VauLAP+L8h6gcTUEbCocvH1UG79GV5wGch3o\nGIm47xG+y42u7lMie7v52cwI33I5tnYKDHKk4dWpAoGAOK3iH7YjoIJEwHwtXyXx\ntP31Tlh1LSsteLzWKRUwcFaYcl5sUyre29ZEgqCBz6YnNmK/A5MxaGbf9dB34MR0\n23q7+OkDEDEs9Ykwxk3PjrmW2lEyVl0gzKdEo17dqJHE2dCd4szOdhOn+I/Kjz4B\neoTsJc5S2is5XJEBGu27FUg=\n-----END PRIVATE KEY-----\n",
  "client_email"=> "smartcellgooglesheet@smartcell-acff1.iam.gserviceaccount.com",
  "client_id"=> "117287287001303808286",
  "auth_uri"=> "https://accounts.google.com/o/oauth2/auth",
  "token_uri"=> "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url"=> "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url"=> "https://www.googleapis.com/robot/v1/metadata/x509/smartcellgooglesheet%40smartcell-acff1.iam.gserviceaccount.com"
];